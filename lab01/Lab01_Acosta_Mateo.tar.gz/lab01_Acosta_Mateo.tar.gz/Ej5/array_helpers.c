#include <stdio.h>
#include <stdlib.h>
#include "array_helpers.h"
#include "mybool.h"

mybool array_is_sorted(int a[], unsigned int length){
    mybool sorted = true;
    unsigned int div = length/2;
    for (unsigned int i=1; i<(div); i++){
        sorted = sorted && (a[i]<=a[i+1]);
    }
    return sorted;
}

unsigned int array_from_file(int array[],
                             unsigned int max_size,
                             const char *filepath) {
    unsigned int length = 0;
    int f = 1;
    FILE *archivo = fopen(filepath, "r");
    if (archivo==NULL){
        printf("Error, the file couldn't be readed\n");
        exit(EXIT_FAILURE);
    }
    for (unsigned int i=0; i<max_size; i++){
        if(f==1){
            f = fscanf(archivo, "%d", &array[i]);
            length = length + 1;  
        }
    }
    fclose(archivo);
    int tmp = length-2;
    if (tmp!=array[0]){
        printf("Error, the actual length of the array is not equal to the length in the file\n");
        exit(EXIT_FAILURE);
    }
    return length;
}

void array_dump(int a[], unsigned int length) {
    printf("[");
    for (unsigned int i=1; i<(length-1); i++){
        if (i!=(length-2)){
            printf("%d, ", a[i]);
        } else {
            printf("%d", a[i]);
        }
    }
    printf("]\n");
}